#include "Windows.h"

#define		IDC_MAIN_MENU			101

#define		IDM_TOOL_SELECT			202
#define		IDM_TOOL_START			203
#define		IDM_TOOL_STOP			204
#define		IDM_TOOL_CLEAR			205

#define		IDM_EXIT				301
#define		IDM_FILE_OPEN			401
#define		IDM_FILE_PORT			411

#define		IDM_ABOUT				302

#define		IDD_SELECT				501
#define		IDC_PORTLIST			502

#define		IDC_STATIC				-1


